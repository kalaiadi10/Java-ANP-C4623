package com.springbootjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootjwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
